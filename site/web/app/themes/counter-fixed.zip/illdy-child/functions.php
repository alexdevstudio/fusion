<?php

Function child_enqueue_scripts() {
	wp_register_style( 'childtheme_style', get_stylesheet_directory_uri() . '/style.css'  );
	wp_enqueue_style( 'childtheme_style' );

	if ( is_front_page() ) {
	//Particles js files
	wp_register_script('particles-js', get_stylesheet_directory_uri() . '/assets/js/particles.js', array('jquery'),'',true);
	wp_register_script('app-particles-js', get_stylesheet_directory_uri() . '/assets/js/app.js', '','',true );
	wp_enqueue_script('particles-js');
	wp_enqueue_script('app-particles-js');
	}
	wp_dequeue_script( 'illdy-scripts');
	wp_register_script('app-particles-js', get_stylesheet_directory_uri() . '/assets/js/app.js', '','',true );


	//End of particles js files
}


add_action( 'wp_enqueue_scripts', 'child_enqueue_scripts');

function remove_css_js_ver( $src ) {
if( strpos( $src, '?ver=' ) )
$src = remove_query_arg( 'ver', $src );
return $src;
}
add_filter( 'style_loader_src', 'remove_css_js_ver', 10, 2 );
add_filter( 'script_loader_src', 'remove_css_js_ver', 10, 2 );

?>
